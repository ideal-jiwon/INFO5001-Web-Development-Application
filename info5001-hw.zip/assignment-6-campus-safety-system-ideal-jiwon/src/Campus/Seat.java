package Campus;

public class Seat {

}
