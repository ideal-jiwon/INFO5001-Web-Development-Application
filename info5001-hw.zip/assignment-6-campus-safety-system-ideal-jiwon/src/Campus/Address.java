package Campus;

public class Address {

  int number;
  String street;
  String zipcode;
  String gps;
  
//Address includes number, street, zipcode, gps
  public Address(int n, String s, String zip, String g) {
    number = n;
    street = s;
    zipcode = zip;
    gps = g;
  }
}

