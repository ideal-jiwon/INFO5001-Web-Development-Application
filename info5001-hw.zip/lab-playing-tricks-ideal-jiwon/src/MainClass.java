
import model.Balloon;

public class MainClass {
    public static void main(String[] args) throws Exception {

        Balloon red = new Balloon("red");

        red.printColor();
    }
}
