package model;

public class Balloon {
  String color;

  public Balloon(String c) {
    color = c;
  }

  public void setColor(String c) {
    color = c;
  }

  public void printColor() {
    System.out.println(color);
  }

}
